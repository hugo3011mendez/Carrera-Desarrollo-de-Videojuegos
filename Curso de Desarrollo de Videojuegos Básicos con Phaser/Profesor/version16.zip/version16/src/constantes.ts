const Constantes = {
    EVENTOS:{
        VIDAS: 'cambiaVidas',
        PUNTUACION: 'cambiaPuntuacion'
    },
    MENU:{
        JUGAR: 'Jugar'
    },
    HUD:{
        VIDAS: 'Vidas:'
    },    
    ESCENAS:{
        MENU: 'Menu',
        NIVEL1: 'Nivel1',
        HUD: 'HUD'
    },
    REGISTRO:{
        VIDAS: 'vidas',
        PUNTUACION: 'puntuacion'
    }
};
export default Constantes;