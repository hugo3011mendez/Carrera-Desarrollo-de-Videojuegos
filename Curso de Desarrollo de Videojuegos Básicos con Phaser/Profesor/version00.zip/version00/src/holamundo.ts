let mensaje : string = "Desarrollo de Videojuegos con Phaser ";
let version : number = 41;
let mensaje2 : string = " y TypeScript";
console.log(mensaje + version + mensaje2);