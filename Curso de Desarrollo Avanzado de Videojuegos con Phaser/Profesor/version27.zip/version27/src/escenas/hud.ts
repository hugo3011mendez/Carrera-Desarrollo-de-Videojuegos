import Constantes from '../constantes';

export default class HUD extends Phaser.Scene {
    private vidasTxt : Phaser.GameObjects.BitmapText;
    private puntuacionTxt : Phaser.GameObjects.BitmapText;
    private relojTxt : Phaser.GameObjects.BitmapText;

    private width: number;
    private height: number;

    constructor(){
        super('HUD');
    }

    init(){
        this.width = this.cameras.main.width;
        this.height = this.cameras.main.height;
    }

    create(): void{
        const nivel1: Phaser.Scene = this.scene.get('Nivel1');
        nivel1.events.on(Constantes.EVENTOS.VIDAS, this.actualizaVidas, this);
        nivel1.events.on(Constantes.EVENTOS.PUNTUACION, this.actualizaPuntuacion, this);
        nivel1.events.on(Constantes.EVENTOS.RELOJ, this.actualizaReloj, this);



        this.vidasTxt = this.add.bitmapText(20,20, Constantes.FUENTES.BITMAP, Constantes.HUD.VIDAS + this.registry.get(Constantes.REGISTRO.VIDAS), 20);
        
        this.puntuacionTxt = this.add.bitmapText(this.width - 50 ,20, Constantes.FUENTES.BITMAP, '000', 20);

        this.relojTxt = this.add.bitmapText(this.width /2 ,20,Constantes.FUENTES.BITMAP, '05:00', 20);


    }

    private actualizaVidas(): void{
        this.vidasTxt.text = Constantes.HUD.VIDAS + this.registry.get('vidas');
    }

    private actualizaPuntuacion(): void {
        this.puntuacionTxt.text = Phaser.Utils.String.Pad(this.registry.get("puntuacion"), 3, '0', 1);
    }

    private actualizaReloj(): void {
        this.relojTxt.text =  this.registry.get(Constantes.REGISTRO.RELOJ);
    }



}